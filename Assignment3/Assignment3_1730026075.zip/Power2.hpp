/*
Author: Michael
Date: 2018-05-06
Function: Calculate the sum of 2^n1, 2^n2 and 2^n3 using header file and Power2() function
*/
#include<stdio.h>
int Power2(int);
//Last modified time: 2018-05-06 16:34