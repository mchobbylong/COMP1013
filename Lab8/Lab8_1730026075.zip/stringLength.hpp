/*
Author: Michael
Date: 2018-04-26
Function: Define "int stringLength(char[])" and use a header file.
*/
#include<stdio.h>
int stringLength(char *);	//The prototype of the function
//Last modified time: 2018-04-26 17:13